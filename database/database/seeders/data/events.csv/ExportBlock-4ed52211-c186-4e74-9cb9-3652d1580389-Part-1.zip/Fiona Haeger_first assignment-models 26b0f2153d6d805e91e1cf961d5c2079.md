# Fiona Haeger_first assignment-models

**Fiona Häger**

**MTM_03-1 Software Development Basics**

**Nico Deblauwe**

**11th, September 2025**

**Assignment 1: Summary of app idea**

**Description:**

I will create an app called first-project. It will be a blog with information on different macronutrients (short “macros”), recipes and their ingredients. The title is “Healthy recipes”. Every recipe has tags to categorize it (e.g. high-protein or vegan).

**Naming of the relations:**

**Macro-Recipe is an M-N relationship**

- One macro belongs to many recipes
- One recipe has many macros (xy % of each macro in every recipe)

**Recipe-Tag is an M-N relationship**

- One recipe has many tags
- One tag belongs to many recipes

**Recipe-Ingredient is a 1-N relationship**

- One recipe has many ingredients
- One ingredient belongs to one recipe

**Models and their properties:**

**Macros: (fats, carbs, protein, fibre)**

Id……………………………………………………………………..int

Name…………………………………………..………………….varchar

Calories per gramm………………………………………….varchar

Recommended amount per day in %..................varchar

Recipe_id…………………………………………………………..int

**Recipes: (chicken salade, salmon, quinoa Bowl, etc.)**

Id……………………………………………………………………..int

Name…………………………………………..………………….varchar

Content………………………………………………………..….text

Macro_id……………………………………………………….…int

Tag_id………………………………………………………………int

Ingredient_id……………………………………………………int

**Tags: (healthy, low-carb, vegan, omega 3, etc.)**

Id……………………………………………………………………..int

Title………………………………………………………………….varchar

Recipe_id………………………………………………………….int

**Ingredients: (salade, pepper, tomatoes, chicken, etc.)**

Id……………………………………………………………………..int

Name……………………………………………………………….varchar

Recipe_id………………………………………………………….int

![image.png](image.png)